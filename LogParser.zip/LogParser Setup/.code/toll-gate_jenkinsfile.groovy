@Library('jpsl') import com.ur.jpsl.Utilities;

def dockerExecute(param) {
  sh('docker run --rm -v "$PWD":/workspace -w /workspace docker-standard-all.ur-update.dk/ur/python-ci:1.3.0 ' + param)
}

standardTollGatePipeline(versionAmend: true) {
  standardNode('linux_docker') {

    def flowType = env && env.FLOW ? Utilities.flowType(env.FLOW) : "main";
    def repo = "stable"
    if (flowType == Utilities.FlowType.DEVELOPER) {
      repo = "experimental-$repo"
    }

    stage('Build') {
      dockerExecute("python3 setup.py bdist_wheel")
    }

    stage('Deploy') {
      dockerExecute("twine upload --repository $repo dist/logparser-*.whl")
    }

    // Cleanup
    deleteDir()
  }
}