@Library('jpsl') _

standardPipeline {
  standardNode('linux_docker') {

    stage('Do nothing') {
      echo("Nothing to do")
    }

    // Cleanup
    deleteDir()
  }
}