#Plugin for pytest-ur-resources test framework.

import pytest
import os
import logging
import tempfile
import datetime

from queue                           import Queue

from threading                       import Thread
from .LiveParser                     import LiveParser
from .RemoteParser                   import RemoteParser
from .decoder.Error                  import Error
from .decoder.LogLineDecoder         import LogLineDecoder

from PrimaryInterfaceClient.Messages import ErrorCodeMessage
from PrimaryInterfaceClient.Messages import Types 

errorCodeFile = None

class TimestampFilter(logging.Filter):
    """
    This is a logging filter which will check for a `timestamp` attribute on a
    given LogRecord, and if present it will override the LogRecord creation time
    to be that of the timestamp (specified as a time.time()-style value).
    This allows one to override the date/time output for log entries by specifying
    `timestamp` in the `extra` option to the logging call.
    """

    def filter(self, record):
        if hasattr(record, 'timestamp'):
            record.created = record.timestamp
        return True

class ErrorWithoutTimestamp(Error):
    def __init__(self, e):
        for key, value in e.__dict__.items():
            setattr(self, key, value)

    def __str__(self):
        return f'{Types.LEVELS(self.level).name} : C{self.code:03d}A{self.arg:03d} : {Types.SOURCES(self.source).name:6s} : {self.text}'

class PytestLogParser(LiveParser, Thread):
    def __init__(self, client):
        LiveParser.__init__(self, client.ipAddress, os.devnull, False, client)
        Thread.__init__(self, daemon = True)
        self.running = True
        
    def run(self):
        self.logger.info("Starting logparser")
        global errorCodeFile
        if errorCodeFile:
            self.readCodes(errorCodeFile.name)
        else:
            self.downloadCodes(None)
            errorCodeFile = tempfile.NamedTemporaryFile()
            errorCodeFile.close()
            self.storeCodes(errorCodeFile.name)

        while self.running:
            for e in self.parseLine():
                line = "LogHistory : " + e.__str__()
                level = 10
                if "DEBUG" in line:
                    level = 11
                elif "INFO" in line:
                    level = 21
                elif "WARN" in line:
                    level = 31
                elif "VIOL" in line:
                    level = 32
                elif "FAULT" in line:
                    level = 33
                self.logger.log(level, line, extra = {"timestamp" : e.timestamp})
        
    def convertMessage(self, *args):
        return ErrorWithoutTimestamp(super().convertMessage(*args))

    def stop(self):
        self.running = False
        self.queue.put(None)
        self.join()

    def setupLogging(self):
        logging.addLevelName(11, 'EMB_DEBUG')
        logging.addLevelName(21, 'EMB_INFO')
        logging.addLevelName(31, 'EMB_WARN')
        logging.addLevelName(32, 'EMB_VIOL')
        logging.addLevelName(33, 'EMB_FAULT')
        self.logger.addFilter(TimestampFilter())



@pytest.hookimpl(trylast=True)
def pytest_ur_configure_robot(robot):
    robot.logparser = PytestLogParser(client = robot.primaryInterface)
    robot.logparser.setupLogging()
    robot.logparser.start()

def pytest_ur_teardown_robot(robot):
    robot.logparser.stop()


