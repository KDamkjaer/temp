"""Version information."""
__version__ = "2.7.2.dev0"