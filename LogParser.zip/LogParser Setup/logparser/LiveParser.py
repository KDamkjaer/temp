import datetime
from queue import Queue, Empty

from .RemoteParser           import RemoteParser
from .decoder.Error          import Error
from .decoder.LogLineDecoder import LogLineDecoder

from PrimaryInterfaceClient  import PrimaryInterfaceClient
from PrimaryInterfaceClient.Messages import ErrorCodeMessage

import re

class Filter(object):

    def isActive(self, e : Error):
        raise NotImplementedError("This function should be overloaded")

class SourceFilter(Filter):

    def __init__(self, node = None, device = None):
        super().__init__()
        self.node = node
        self.device = device

    @staticmethod
    def _decodeSource(source):
        if source < 0: return -1, -1
        if source < 100:
            node   = 0
        else:
            node   = (source % 10) + 1
            if node == 8: node = 0xE
            if node == 9: node = 0xD

        device = 1 << ((source // 10) % 10)

        return node, device

    def isActive(self, e : Error):
        node, device = self._decodeSource(e.source)
        node = node if self.node != 0xF else 0xF
        return self.node == node and self.device & device

class CodeFilter(Filter):

    def __init__(self, code : int, arg : int = None):
        super().__init__()
        self.code = code
        self.arg = arg

    def isActive(self, e : Error):
        code = e.code if self.code != None else None
        arg = e.arg if self.arg != None else None
        return code == self.code and arg == self.arg

def filter_factory(s):
    m = re.match('(?:C(?P<code>\d+)(?:A(?P<arg>\d+))?)|(?:S?(?P<source>(?P<hex>0x)?[0-9A-F]+))', s)

    if m.group('code'):
        arg = int(m.group('arg')) if m.group('arg') != None else None
        return CodeFilter(int(m.group('code')), arg)

    if m.group('source'):
        base = 16 if m.group('hex') else 10
        source = int(m.group('source'), base)
        device   = (source & 0xF0) >> 4
        node =  source & 0x0F
        return SourceFilter(node, device)


class LiveParser(RemoteParser):
    def __init__(self, ip, outPath, should_print, client = None):
        super().__init__(ip, outPath)
        self.client = client
        if self.client == None:
            self.client = PrimaryInterfaceClient(self.src)
            self.client.start()
        self.should_print = should_print
        self.queue  = Queue()
        self.client.addHandler(ErrorCodeMessage, self.queue.put)
        self.filters = []

    def addFilter(self, filter : Filter):
        self.filters.append(filter)

    def parseLine(self):
        if self.d.codes == None:
            raise RuntimeError("No errorcodes have been loaded")
        decoder = LogLineDecoder(self.d.codes)

        for e in self.getError():
            if not e.text:
                e.text = decoder.generateMsgString(e)
            if self.should_print:
                print(e)
                
            yield e
    
    def getError(self):
        last_timestamp = float('inf')
        time_offset = datetime.datetime.now()

        while True:
            try:
                error_msg = self.queue.get(timeout=2)
            except Empty:
                continue

            if error_msg == None:
                return

            if len(self.filters) > 0:
                filtered = False
                for f in self.filters:
                    filtered = filtered or f.isActive(error_msg)
                if not filtered: continue

            if error_msg.timestamp < last_timestamp:
                time_offset = datetime.datetime.now() - datetime.timedelta(microseconds= error_msg.timestamp)
            last_timestamp = error_msg.timestamp

            yield self.convertMessage(error_msg, time_offset)

    def convertMessage(self, msg, time_offset):
        e = Error()
        e.timestamp = time_offset + datetime.timedelta(microseconds=msg.timestamp)
        e.source    = msg.source
        e.code      = msg.code
        e.arg       = msg.arg
        e.level     = msg.level
        e.datatype  = msg.datatype
        e.data      = msg.data
        e.text      = msg.text
        return e

    @staticmethod
    def main():
        import logging
        parser = LiveParser.getArgumentParser()
        parser.add_argument("--silent", action="store_true", help="Don't output log to stdout")
        parser.add_argument("--filters", metavar='FILTER', nargs='+', type=filter_factory, help="Filter rules")

        args = parser.parse_args()

        ip = LiveParser._generateIp(args.ip)

        outPath = f'auto_parsed_{ip}.txt'
        if args.outPath:
            outPath = args.outPath

        LiveParser.setupLogging(args.debug)

        lp = LiveParser(ip, outPath, not args.silent)

        if args.filters != None:
            for f in args.filters:
                lp.addFilter(f)

        if (args.definition_file):
            lp.readCodes(args.definition_file)
        else:
            lp.downloadCodes(args.definition_version)
            if (args.definition_save):
                lp.storeCodes(args.definition_save)
        try:
            lp.parse()
        except KeyboardInterrupt:
            return

if __name__ == '__main__':
    LiveParser.main()
