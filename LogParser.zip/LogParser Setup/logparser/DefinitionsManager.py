import urllib.request
import xml.etree.ElementTree as ET
import logging
import json
from abc import ABC, abstractmethod

class DefinitionsManager(ABC):
    def __init__(self):
        self._codes = None
        self.logger = logging.getLogger(self.__class__.__name__)

    @property
    def codes(self):
        if not self._codes:
            self._loadcodes()
        return self._codes

    @abstractmethod
    def _loadcodes(self):
        raise NotImplementedError()

class DefinitionsFileLoader(DefinitionsManager):

    def __init__(self, path):
        super().__init__()
        self.path = path

    def _loadcodes(self):
        with open(self.path) as f:
            self._codes = json.load(f)

class DefinitionsDownloader(DefinitionsManager):

    baseURL = 'https://nexus.urrd.dk/repository/maven-standard-release-hosted/com/ur/errorcodes/definitions/'
    def __init__(self, version = None):
        super().__init__()
        self.version = version

    def storeCodes(self, path):
        codes = self.codes
        with open(path, 'w') as f:
            self.logger.info("Saving JSON to {0}".format(path))
            json.dump(codes, f, indent=2)

    def _loadcodes(self):
        self._getLatestVersion()
        self.logger.info("Downloading JSON")
        url = self.baseURL + '{0}/definitions-{0}.json'.format(self.version)
        self.logger.debug('Downloading from: {0}'.format(url))
        with urllib.request.urlopen(url) as f:
            self._codes = json.load(f)

    def _getLatestVersion(self):
        if self.version:
            return
        
        self.logger.info("Locating version")
        with urllib.request.urlopen(self.baseURL + 'maven-metadata.xml') as f:
            tree = ET.parse(f)
            self.version = tree.find('.//release').text
        self.logger.info('Found version: {0}'.format(self.version))

