from .version import __version__
from .BaseParser import BaseParser

class LogParser(BaseParser):
    def __init__(self, inPath, outPath):
        super().__init__(outPath)
        self.src = inPath

    def readData(self):
        with open(self.src, 'r', encoding="utf8") as rf:
           for line in self.readFromBuffer(rf):
               yield line

    @staticmethod
    def main():
        import argparse
        import logging

        parser = argparse.ArgumentParser(add_help=True)
        parser.add_argument('-i','--in', dest='inPath', help='Specify output path. Default is log_history.txt', type=str, default='log_history.txt', metavar='filename')
        parser.add_argument('-o','--out', dest='outPath', help='Specify output path. Default is log.txt', type=str, default='log.txt', metavar='filename')
        parser.add_argument('-v','--version', action='version', version=f'%(prog)s, scope v{__version__}')
        parser.add_argument('-dv', '--definition_version', help='Version of errorcodes to download', type=str, metavar='version')
        parser.add_argument('-df', '--definition_file', help='Path to errorcodes definition json', type=str, metavar='filename')
        parser.add_argument('-ds', '--definition_save', help='Path to store downloaded errorcodes definition json', type=str, metavar='filename')
        parser.add_argument('--debug', help='Enables debug logging', default=False, action='store_true')
        args = parser.parse_args()

        LogParser.setupLogging(args.debug)

        lp = LogParser(args.inPath, args.outPath)
        if (args.definition_file):
            lp.readCodes(args.definition_file)
        else:
            lp.downloadCodes(args.definition_version)
            if (args.definition_save):
                lp.storeCodes(args.definition_save)

        lp.parse()

if __name__ == '__main__':
    LogParser.main()