from .version import __version__
from .BaseParser import BaseParser
import paramiko
import socket

class IgnoreMissingKeyPolicy(paramiko.client.MissingHostKeyPolicy):
    def missing_host_key(self, client, hostname, key):
        pass

class RemoteParser(BaseParser):
    def __init__(self, ip, outPath):
        super().__init__(outPath)
        self.src = self._generateIp(ip)

    def flushPoliscopeLog(self):
        self.logger.info('Requesting polyscope log flush')
        try:
            with socket.create_connection((self.src, 29999), timeout=0.2) as s:
                f = s.makefile(mode='rw')
                
                # Read the connection message
                f.readline()[:-1]

                # Send save command
                f.write('savelog\n')
                f.flush()
                
                # Get confirmation
                res = f.readline()[:-1]
                if (res == 'Log saved to disk'):
                    self.logger.info('Polyscope log flushed')
                else:
                    self.logger.warn(f'Unexpeted response from polyscope: "{res}"')
        except socket.timeout:
            self.logger.warn(f'Failed while flushin polyscope log')

    def readData(self):
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(IgnoreMissingKeyPolicy)
        client.connect(self.src, username = 'root', password= 'easybot')
        sftp_client = client.open_sftp()

        self.flushPoliscopeLog()

        with sftp_client.open('/root/log_history.txt', bufsize = 5 * 2**20) as f:
           for line in self.readFromBuffer(f):
               yield line

    @staticmethod
    def _generateIp(ip):
        ipElements = [int(element) for element in ip.split('.')]

        # assert legal ip format
        assert len(ipElements) <=4
        for element in ipElements:
            assert (element <= 255) and (element >=0)

        # set ip
        defaultIp = [10,53,255,0]
        ip = defaultIp[:-len(ipElements)] + ipElements
        return '{}.{}.{}.{}'.format(*ip)


    @staticmethod
    def getArgumentParser():
        import argparse

        parser = argparse.ArgumentParser(add_help=True)
        parser.add_argument('ip', help='Specify IP-address', type=str)
        parser.add_argument('-o','--out', dest='outPath', help='Specify output path. Default is log.txt', type=str, metavar='filename')
        parser.add_argument('-v','--version', action='version', version=f'%(prog)s, scope v{__version__}')
        parser.add_argument('-dv', '--definition_version', help='Version of errorcodes to download', type=str, metavar='version')
        parser.add_argument('-df', '--definition_file', help='Path to errorcodes definition json', type=str, metavar='filename')
        parser.add_argument('-ds', '--definition_save', help='Path to store downloaded errorcodes definition json', type=str, metavar='filename')
        parser.add_argument('--debug', help='Enables debug logging', default=False, action='store_true')
        return parser

    @staticmethod
    def main():
        import logging
        parser = RemoteParser.getArgumentParser()

        args = parser.parse_args()

        ip = RemoteParser._generateIp(args.ip)

        outPath = f'auto_parsed_{ip}.txt'
        if args.outPath:
            outPath = args.outPath

        RemoteParser.setupLogging(args.debug)

        lp = RemoteParser(ip, outPath)
        if (args.definition_file):
            lp.readCodes(args.definition_file)
        else:
            lp.downloadCodes(args.definition_version)
            if (args.definition_save):
                lp.storeCodes(args.definition_save)

        lp.parse()

if __name__ == '__main__':
    RemoteParser.main()
