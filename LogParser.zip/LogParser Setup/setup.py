"""
Script to generate the installer for logger remote.
"""

import os
import os.path
from runpy import run_path
from setuptools import setup, find_packages


def read(*rnames):
    return open(os.path.join(os.path.dirname(__file__), *rnames), 'rb').read().decode("UTF-8")

with open('requirements.txt', 'r') as f:
    requirements = [l.strip() for l in f if not l.startswith("--extra-index-url")]

version = run_path('./logparser/version.py')['__version__']

setup(
    name='logparser',
    version=version,
    maintainer='Jon Henneberg',
    maintainer_email='jhh@universal-robots.com',
    license='Universal Robots License',
    platforms=["any"],
    python_requires='>=3.6',
    description='A Python library for reading datacope data via socket.',
    long_description=read('README.md'),
    install_requires=requirements,
    classifiers=[
        'Development Status :: 4 - Beta',
        'Environment :: Console',
        'Intended Audience :: Other Audience',
        'License :: Other/Proprietary License',
        'Natural Language :: English',
        'Operating System :: Microsoft :: Windows',
        'Operating System :: Unix',
        'Topic :: Office/Business',
        'Topic :: Utilities',
    ],
    packages=find_packages(exclude = []),
    keywords=['library', 'utility'],
        entry_points={
        'console_scripts': [
            'logparser=logparser.LogParser:LogParser.main',
            'logparserremote=logparser.RemoteParser:RemoteParser.main',
            'logparserlive=logparser.LiveParser:LiveParser.main',
        ],
        'pytest11': [
            'pytestur_logparser=logparser.plugin',
        ],
    },
)