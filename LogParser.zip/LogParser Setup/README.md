# Log Parser #

## Installing module
To install run `pip install logparser` or checkout module and run `pip install .` from repository root folder

This installs into python allowing the app to executed from any path by simply typing `logparser` for local files or `logparserremote` files on a robot

### Developer mode
If you want to be able to modify the code but still use from any location you can install it in developer mode by running `pip install -e .`

This will install it but point to the files of this repository

## Dependecies ##
Python3.6+

## Using logparser ##

This is used for local files, Type `logparser --help` for a list of arguments

## Using logparserremote ##

This is used for files located on a Robot, Type `logparser --help` for a list of arguments